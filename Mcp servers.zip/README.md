# 🌤️ Masterclass MCP — Assistant Météo avec Claude
**AI4Africa Ignition · Jeudi 07 mai 2026**

> **Objectif :** À la fin de cet atelier, vous pourrez demander à Claude :
> *"Quelle est la météo à Yaoundé ?"* et Claude répondra avec des données en temps réel.

---

## ⚡ Installation rapide (3 étapes)

```bash
# 1. Vérifiez que Python 3.10+ est installé
python --version

# 2. Installez toutes les dépendances
pip install -r requirements.txt

# 3. Lancez Jupyter
jupyter notebook
```

Jupyter va ouvrir dans votre navigateur. Ouvrez ensuite les notebooks dans l'ordre.

---

## 📚 Les 4 Notebooks (45 minutes)

| Notebook | Durée | Ce qu'on apprend |
|----------|-------|-----------------|
| `01_decouverte_api.ipynb` | 10 min | Qu'est-ce qu'une API ? Premier appel météo |
| `02_fonctions_python.ipynb` | 10 min | Transformer le code brut en fonctions propres |
| `03_serveur_mcp.ipynb` | 15 min | Créer le serveur MCP que Claude va utiliser |
| `04_tester_connecter.ipynb` | 10 min | Tester que tout marche, connecter à Claude |

---

## 🗂️ Structure du projet

```
MCP 2/
├── README.md                    ← Ce fichier
├── requirements.txt             ← Dépendances à installer
├── 01_decouverte_api.ipynb      ← Notebook 1
├── 02_fonctions_python.ipynb    ← Notebook 2
├── 03_serveur_mcp.ipynb         ← Notebook 3
├── 04_tester_connecter.ipynb    ← Notebook 4
└── server.py                    ← Serveur MCP final (prêt à lancer)
```

---

## 🔌 Connecter à Claude Desktop (Notebook 4)

Ajoutez ceci dans la configuration de Claude Desktop
(`Paramètres → Développeur → Modifier la configuration`) :

```json
{
  "mcpServers": {
    "meteo-africa": {
      "command": "python",
      "args": ["CHEMIN_COMPLET/server.py"]
    }
  }
}

dans notre cas 

"mcpServers": {
    "meteo-africa": {
      "command": "python",
      "args": [
        "C:/Users/axiat/Desktop/MCP/MCP2/server.py"
      ]
    }
  }
```

Remplacez `CHEMIN_COMPLET` par le chemin réel vers ce dossier.

---

## 💬 Phrases à tester dans Claude

Une fois connecté, essayez ces questions :

```
Quelle est la météo à Yaoundé en ce moment ?
Compare la météo entre Dakar, Abidjan et Paris.
Qu'est-ce que je dois mettre pour aller à Douala aujourd'hui ?
Il fait quel temps à Antananarivo ?
```

---

## 🛠️ En cas de problème

| Problème | Solution |
|----------|----------|
| `ModuleNotFoundError: requests` | `pip install requests` |
| `ModuleNotFoundError: mcp` | `pip install mcp` |
| Jupyter ne s'ouvre pas | `pip install jupyter notebook` |
| Serveur MCP absent dans Claude | Redémarrer Claude Desktop |
| Ville introuvable | Essayer un nom plus simple (ex: "Abidjan" plutôt que "Abidjan CI") |

---

**API utilisée :** [Open-Meteo](https://open-meteo.com) — Gratuite, sans inscription, sans clé API
