# Formation LangChain pour Développeurs

Bienvenue dans le dépôt de la formation dédiée à **LangChain**, le framework de référence pour le développement d'applications basées sur les Modèles de Langage (LLMs). 

Ce support de formation est conçu pour être un guide d'apprentissage progressif, hébergé sur GitLab, avec des expérimentations pratiques en Python sous forme de notebooks Jupyter.

## Objectifs de la Formation

*   Comprendre l'écosystème LangChain et son architecture modulaire.
*   Maîtriser l'interaction avec différents LLMs et la gestion des types de messages.
*   Concevoir et réutiliser des requêtes complexes avec les **Prompt Templates**.
*   Créer des pipelines d'exécution fluides en combinant plusieurs composants avec les **Chains** (LCEL).
*   Ajouter un contexte conversationnel persistant aux agents grâce à la **Memory**.
*   Construire des **Agents IA** autonomes capables de choisir et d'utiliser des outils externes.
*   Implémenter l'architecture **RAG** (Retrieval-Augmented Generation) de A à Z.

## Structure de la Formation

Le cours est découpé en notebooks numérotés à suivre dans l'ordre de progression logique :

1.  **`01_introduction.ipynb`** : Découverte du framework, concepts de base et premier appel à un LLM.
2.  **`02_llm_et_messages.ipynb`** : Les abstractions pour les modèles d'IA, les ChatModels, et la structuration des messages.
3.  **`03_prompt_templates.ipynb`** : Ingénierie de prompts paramétrables pour structurer l'entrée des modèles.
4.  **`04_chains.ipynb`** : Combinaison de prompts, modèles et output parsers via la syntaxe LCEL.
5.  **`05_memory.ipynb`** : Ajout et gestion de l'historique pour construire des chatbots contextuels.
6.  **`06_agents.ipynb`** : Délégation de tâches et de raisonnement à l'IA en l'équipant d'outils interactifs.
7.  **`07_rag.ipynb`** : Construction d'un moteur de question-réponse sur des documents privés (Chargement, découpage, vectorisation).
8.  **`08_reference_complete.ipynb`** : Notebook de synthèse regroupant tous les éléments clés comme un "Cheatsheet" global.

## Prérequis Techniques

*   **Environnement :** Python 3.9+ recommandé.
*   **Outils :** Jupyter Notebook ou un IDE compatible (Visual Studio Code avec extension Jupyter recommandé).
*   **Services :** Une ou plusieurs clés d'API valides (comme OpenAI, Anthropic, Mistral...) selon les modèles ciblés.

## Mise en route (Démarrage Rapide)

1.  **Cloner le dépôt GitLab :**
    ```bash
    git clone <votre_url_gitlab>/Langchain_Formation.git
    cd Langchain_Formation
    ```

2.  **Environnement Virtuel Python :**
    ```bash
    python -m venv venv
    # Sur Windows :
    .\venv\Scripts\activate
    # Sur Linux/Mac :
    source venv/bin/activate
    ```

3.  **Installer les dépendances :**
    Assurez-vous d'installer les bibliothèques requises :
    ```bash
    pip install jupyter langchain python-dotenv
    # (Complétez avec langchain-openai, langchain-anthropic, etc. en fonction de l'environnement)
    ```

4.  **Variables d'Environnement :**
    Un fichier d'exemple est fourni. Dupliquez-le pour créer votre configuration locale :
    ```bash
    # Sur Windows (PowerShell)
    Copy-Item .env.example .env
    # Sur bash
    cp .env.example .env
    ```
    Ouvrez le fichier `.env` nouvellement créé et renseignez-y vos clés API :
    ```env
    OPENAI_API_KEY="sk-..."
    # etc...
    ```
    > ⚠️ **Attention :** Le fichier `.env` ne doit **jamais** être commité sur GitLab.

5.  **Démarrer l'environnement Jupyter :**
    ```bash
    jupyter notebook
    ```
    Votre navigateur s'ouvrira (par défaut sur `localhost:8888`). Commencez par ouvrir le notebook `01_introduction.ipynb` !

## Contributions & Améliorations

Ce support est évolutif. Si vous repérez des erreurs, ou si vous souhaitez proposer des ajouts (nouveaux cas d'usage, corrections), n'hésitez pas à ouvrir une Issue ou à soumettre directement une Merge Request sur le repôt.
